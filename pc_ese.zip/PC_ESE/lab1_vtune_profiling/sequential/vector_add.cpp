#include <iostream>
#include <vector>
#include <chrono>

void vector_add(const std::vector<float>& a, const std::vector<float>& b, std::vector<float>& c) {
    for (size_t i = 0; i < a.size(); i++) {
        c[i] = a[i] + b[i];
    }
}

int main() {
    const int N = 1000000;
    std::vector<float> a(N, 1.0f);
    std::vector<float> b(N, 2.0f);
    std::vector<float> c(N);
    
    auto start = std::chrono::high_resolution_clock::now();
    vector_add(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    // Verify results
    bool correct = true;
    for (size_t i = 0; i < N; i++) {
        if (c[i] != 3.0f) {
            correct = false;
            break;
        }
    }
    std::cout << "Results are " << (correct ? "correct" : "incorrect") << "\n";
    
    return 0;
}

/*
Compilation and Execution Commands:
1. Compile with debug symbols:
   g++ -std=c++11 -O3 -g vector_add.cpp -o vector_add

2. Run with VTune:
   vtune -collect hotspots ./vector_add
   vtune -collect memory-access ./vector_add
   vtune -collect uarch-exploration ./vector_add

3. View results:
   vtune-gui results.vtune

Note:
- Make sure Intel VTune Profiler is installed
- The code should be compiled with debug symbols (-g) for better profiling
- Different VTune collection types:
  - hotspots: Identify performance bottlenecks
  - memory-access: Analyze memory access patterns
  - uarch-exploration: Analyze CPU microarchitecture usage
*/ 