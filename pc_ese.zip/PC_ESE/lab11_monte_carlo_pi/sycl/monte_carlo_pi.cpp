#include <CL/sycl.hpp>
#include <iostream>
#include <random>
#include <chrono>

namespace sycl = cl::sycl;

double monte_carlo_pi(int num_samples) {
    // Create a SYCL queue
    sycl::queue q(sycl::default_selector{});
    
    // Create buffer for result
    sycl::buffer<int, 1> result_buf(sycl::range<1>(1));
    
    // Submit work to queue
    q.submit([&](sycl::handler& h) {
        auto result_acc = result_buf.get_access<sycl::access::mode::write>(h);
        
        // Create local memory for reduction
        sycl::accessor<int, 1, sycl::access::mode::read_write, sycl::access::target::local> 
            local_result(sycl::range<1>(1), h);
        
        h.parallel_for(sycl::nd_range<1>(sycl::range<1>(num_samples), sycl::range<1>(256)), 
                     [=](sycl::nd_item<1> item) {
            int local_id = item.get_local_id(0);
            int global_id = item.get_global_id(0);
            
            // Initialize local memory
            if (local_id == 0) {
                local_result[0] = 0;
            }
            item.barrier(sycl::access::fence_space::local_space);
            
            // Generate random numbers and count points inside circle
            if (global_id < num_samples) {
                sycl::vec<float, 2> rand = sycl::rand<float, 2>(item.get_global_id(0));
                float x = rand.x() * 2.0f - 1.0f;
                float y = rand.y() * 2.0f - 1.0f;
                
                if (x * x + y * y <= 1.0f) {
                    sycl::atomic_ref<int, sycl::memory_order::relaxed, 
                                   sycl::memory_scope::work_group> 
                        count_atomic(local_result[0]);
                    count_atomic.fetch_add(1);
                }
            }
            item.barrier(sycl::access::fence_space::local_space);
            
            // Reduce to global memory
            if (local_id == 0) {
                sycl::atomic_ref<int, sycl::memory_order::relaxed, 
                               sycl::memory_scope::device> 
                    global_atomic(result_acc[0]);
                global_atomic.fetch_add(local_result[0]);
            }
        });
    });
    
    // Wait for completion
    q.wait();
    
    // Get result
    auto result_acc = result_buf.get_access<sycl::access::mode::read>();
    return 4.0 * result_acc[0] / num_samples;
}

int main() {
    const int num_samples = 100000000;
    
    auto start = std::chrono::high_resolution_clock::now();
    double pi = monte_carlo_pi(num_samples);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    std::cout << "OneAPI SYCL Monte Carlo PI Calculation\n";
    std::cout << "Number of samples: " << num_samples << "\n";
    std::cout << "Estimated PI: " << pi << "\n";
    std::cout << "Error: " << std::abs(pi - 3.14159265358979323846) << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    return 0;
} 

// Compile with:
// g++ -o monte_carlo_pi monte_carlo_pi.cpp -std=c++11 -lOpenCL
// Run with:
// ./monte_carlo_pi
