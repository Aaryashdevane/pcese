#include <stdio.h>
#include <stdlib.h>
#include <openacc.h>

void vector_add(float* a, float* b, float* c, int n) {
    #pragma acc parallel loop copyin(a[0:n], b[0:n]) copyout(c[0:n])
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i];
    }
}

int main() {
    const int N = 1000000;
    float* a = (float*)malloc(N * sizeof(float));
    float* b = (float*)malloc(N * sizeof(float));
    float* c = (float*)malloc(N * sizeof(float));
    
    // Initialize vectors
    for (int i = 0; i < N; i++) {
        a[i] = 1.0f;
        b[i] = 2.0f;
    }
    
    double start_time = omp_get_wtime();
    vector_add(a, b, c, N);
    double end_time = omp_get_wtime();
    
    printf("Time taken: %f seconds\n", end_time - start_time);
    
    // Verify results
    int correct = 1;
    for (int i = 0; i < N; i++) {
        if (c[i] != 3.0f) {
            correct = 0;
            break;
        }
    }
    printf("Results are %s\n", correct ? "correct" : "incorrect");
    
    free(a);
    free(b);
    free(c);
    
    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   gcc -fopenacc -O3 vector_add.c -o vector_add_openacc

2. Run:
   ./vector_add_openacc

Note:
- Make sure you have GCC with OpenACC support installed
- The code requires an OpenACC-capable GPU
- You might need to set the ACC_DEVICE_TYPE environment variable:
  export ACC_DEVICE_TYPE=nvidia  # For NVIDIA GPUs
  export ACC_DEVICE_TYPE=host    # For CPU execution
- For optimal performance, ensure your GPU has enough memory to handle the vector size
*/ 