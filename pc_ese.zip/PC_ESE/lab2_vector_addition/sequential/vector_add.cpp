#include <iostream>
#include <vector>
#include <chrono>

void vector_add(const std::vector<float>& a, const std::vector<float>& b, std::vector<float>& c) {
    for (size_t i = 0; i < a.size(); i++) {
        c[i] = a[i] + b[i];
    }
}

int main() {
    const int N = 1000000; // Size of vectors
    std::vector<float> a(N, 1.0f); // Initialize with 1.0
    std::vector<float> b(N, 2.0f); // Initialize with 2.0
    std::vector<float> c(N, 0.0f); // Result vector

    auto start = std::chrono::high_resolution_clock::now();
    vector_add(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;

    // Verify results
    bool correct = true;
    for (int i = 0; i < N; i++) {
        if (c[i] != 3.0f) {
            correct = false;
            break;
        }
    }

    std::cout << "Sequential Vector Addition\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result verification: " << (correct ? "PASSED" : "FAILED") << std::endl;

    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   g++ -std=c++11 -O3 vector_add.cpp -o vector_add

2. Run:
   ./vector_add

Note: Make sure you have g++ installed and have appropriate permissions to execute the compiled binary.
*/ 