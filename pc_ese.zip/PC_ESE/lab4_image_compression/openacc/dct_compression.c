#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <openacc.h>

#define BLOCK_SIZE 8
#define PI 3.14159265358979323846

void dct_transform(float* input, float* output, int width, int height) {
    #pragma acc parallel loop collapse(2) copyin(input[0:width*height]) copyout(output[0:width*height])
    for (int v = 0; v < height; v++) {
        for (int u = 0; u < width; u++) {
            float sum = 0.0f;
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    float cu = (u == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                    float cv = (v == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                    float cos_u = cos((2 * x + 1) * u * PI / (2 * width));
                    float cos_v = cos((2 * y + 1) * v * PI / (2 * height));
                    sum += input[y * width + x] * cu * cv * cos_u * cos_v;
                }
            }
            output[v * width + u] = sum * 2.0f / sqrt(width * height);
        }
    }
}

void quantize(float* dct_coeffs, float* quantization_table, int size) {
    #pragma acc parallel loop copyin(dct_coeffs[0:size], quantization_table[0:size])
    for (int i = 0; i < size; i++) {
        dct_coeffs[i] = round(dct_coeffs[i] / quantization_table[i]);
    }
}

void process_block(float* input, float* output, float* quantization_table,
                  int width, int height) {
    #pragma acc parallel loop collapse(2) copyin(input[0:width*height], quantization_table[0:BLOCK_SIZE*BLOCK_SIZE]) copyout(output[0:width*height])
    for (int block_y = 0; block_y < height; block_y += BLOCK_SIZE) {
        for (int block_x = 0; block_x < width; block_x += BLOCK_SIZE) {
            float block[BLOCK_SIZE][BLOCK_SIZE];
            float dct_block[BLOCK_SIZE][BLOCK_SIZE];

            // Load block
            for (int y = 0; y < BLOCK_SIZE; y++) {
                for (int x = 0; x < BLOCK_SIZE; x++) {
                    block[y][x] = input[(block_y + y) * width + (block_x + x)];
                }
            }

            // Perform DCT
            for (int v = 0; v < BLOCK_SIZE; v++) {
                for (int u = 0; u < BLOCK_SIZE; u++) {
                    float sum = 0.0f;
                    for (int y = 0; y < BLOCK_SIZE; y++) {
                        for (int x = 0; x < BLOCK_SIZE; x++) {
                            float cu = (u == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                            float cv = (v == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                            float cos_u = cos((2 * x + 1) * u * PI / (2 * BLOCK_SIZE));
                            float cos_v = cos((2 * y + 1) * v * PI / (2 * BLOCK_SIZE));
                            sum += block[y][x] * cu * cv * cos_u * cos_v;
                        }
                    }
                    dct_block[v][u] = sum * 2.0f / BLOCK_SIZE;
                }
            }

            // Quantize and store
            for (int y = 0; y < BLOCK_SIZE; y++) {
                for (int x = 0; x < BLOCK_SIZE; x++) {
                    int idx = y * BLOCK_SIZE + x;
                    output[(block_y + y) * width + (block_x + x)] = 
                        round(dct_block[y][x] / quantization_table[idx]);
                }
            }
        }
    }
}

int main() {
    const int width = 512;
    const int height = 512;
    const int total_pixels = width * height;

    // Allocate memory
    float* input_image = (float*)malloc(total_pixels * sizeof(float));
    float* output_image = (float*)malloc(total_pixels * sizeof(float));
    float* quantization_table = (float*)malloc(BLOCK_SIZE * BLOCK_SIZE * sizeof(float));

    // Initialize input image and quantization table
    for (int i = 0; i < total_pixels; i++) {
        input_image[i] = (float)(i % 256);
    }
    for (int i = 0; i < BLOCK_SIZE * BLOCK_SIZE; i++) {
        quantization_table[i] = 1.0f + (i % BLOCK_SIZE) + (i / BLOCK_SIZE);
    }

    // Process image
    process_block(input_image, output_image, quantization_table, width, height);

    // Calculate compression ratio
    int non_zero = 0;
    for (int i = 0; i < total_pixels; i++) {
        if (output_image[i] != 0) non_zero++;
    }
    float compression_ratio = (float)total_pixels / non_zero;

    printf("OpenACC DCT Image Compression\n");
    printf("Compression ratio: %.2f:1\n", compression_ratio);

    // Free memory
    free(input_image);
    free(output_image);
    free(quantization_table);

    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   gcc -fopenacc -O3 -lm dct_compression.c -o dct_compression_openacc

2. Run:
   ./dct_compression_openacc

Note:
- Make sure you have GCC with OpenACC support installed
- The code requires an OpenACC-capable GPU
- You might need to set the ACC_DEVICE_TYPE environment variable:
  export ACC_DEVICE_TYPE=nvidia  # For NVIDIA GPUs
  export ACC_DEVICE_TYPE=host    # For CPU execution
- For optimal performance, ensure your GPU has enough memory to handle the image size
*/ 