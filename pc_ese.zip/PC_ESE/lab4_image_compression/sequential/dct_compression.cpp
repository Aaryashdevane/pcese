#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <chrono>

const int BLOCK_SIZE = 8;
const float PI = 3.14159265358979323846;

// DCT transformation
void dct_transform(const std::vector<float>& input, std::vector<float>& output, int width, int height) {
    for (int v = 0; v < height; v++) {
        for (int u = 0; u < width; u++) {
            float sum = 0.0f;
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    float cu = (u == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                    float cv = (v == 0) ? 1.0f / sqrt(2.0f) : 1.0f;
                    float cos_u = cos((2 * x + 1) * u * PI / (2 * width));
                    float cos_v = cos((2 * y + 1) * v * PI / (2 * height));
                    sum += input[y * width + x] * cu * cv * cos_u * cos_v;
                }
            }
            output[v * width + u] = sum * 2.0f / sqrt(width * height);
        }
    }
}

// Quantization
void quantize(std::vector<float>& dct_coeffs, const std::vector<float>& quantization_table) {
    for (size_t i = 0; i < dct_coeffs.size(); i++) {
        dct_coeffs[i] = round(dct_coeffs[i] / quantization_table[i]);
    }
}

void compress_image(std::vector<float>& image, int width, int height) {
    for (int y = 0; y < height; y += BLOCK_SIZE) {
        for (int x = 0; x < width; x += BLOCK_SIZE) {
            std::vector<float> block(BLOCK_SIZE * BLOCK_SIZE);
            
            // Extract block
            for (int i = 0; i < BLOCK_SIZE; i++) {
                for (int j = 0; j < BLOCK_SIZE; j++) {
                    block[i * BLOCK_SIZE + j] = image[(y + i) * width + (x + j)];
                }
            }
            
            // Apply DCT
            dct_transform(block, block, BLOCK_SIZE, BLOCK_SIZE);
            
            // Store back
            for (int i = 0; i < BLOCK_SIZE; i++) {
                for (int j = 0; j < BLOCK_SIZE; j++) {
                    image[(y + i) * width + (x + j)] = block[i * BLOCK_SIZE + j];
                }
            }
        }
    }
}

int main() {
    const int width = 512;
    const int height = 512;
    const int total_pixels = width * height;

    // Create sample image (gradient)
    std::vector<float> input_image(total_pixels);
    for (int i = 0; i < total_pixels; i++) {
        input_image[i] = static_cast<float>(i % 256);
    }

    // Initialize quantization table (simplified)
    std::vector<float> quantization_table(BLOCK_SIZE * BLOCK_SIZE, 1.0f);
    for (int i = 0; i < BLOCK_SIZE * BLOCK_SIZE; i++) {
        quantization_table[i] = 1.0f + (i % BLOCK_SIZE) + (i / BLOCK_SIZE);
    }

    auto start = std::chrono::high_resolution_clock::now();
    compress_image(input_image, width, height);
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";

    // Calculate compression ratio (simplified)
    int non_zero = 0;
    for (float val : input_image) {
        if (val != 0) non_zero++;
    }
    float compression_ratio = static_cast<float>(total_pixels) / non_zero;

    std::cout << "Sequential DCT Image Compression\n";
    std::cout << "Compression ratio: " << compression_ratio << ":1\n";

    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   g++ -std=c++11 -O3 -lm dct_compression.cpp -o dct_compression

2. Run:
   ./dct_compression

Note: Make sure you have g++ installed and have appropriate permissions to execute the compiled binary.
*/ 