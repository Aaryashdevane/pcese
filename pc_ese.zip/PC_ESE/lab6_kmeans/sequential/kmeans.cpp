#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include <chrono>

struct Point {
    float x, y;
};

float distance(const Point& a, const Point& b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

void kmeans(std::vector<Point>& points, std::vector<Point>& centroids,
           std::vector<int>& assignments, int k, int max_iterations) {
    int n = points.size();
    
    // Initialize assignments
    assignments.resize(n);
    
    for (int iter = 0; iter < max_iterations; iter++) {
        // Assignment step
        for (int i = 0; i < n; i++) {
            float min_dist = INFINITY;
            int best_cluster = 0;
            
            for (int j = 0; j < k; j++) {
                float dist = distance(points[i], centroids[j]);
                if (dist < min_dist) {
                    min_dist = dist;
                    best_cluster = j;
                }
            }
            assignments[i] = best_cluster;
        }
        
        // Update step
        std::vector<int> counts(k, 0);
        std::vector<Point> new_centroids(k, {0.0f, 0.0f});
        
        for (int i = 0; i < n; i++) {
            int cluster = assignments[i];
            new_centroids[cluster].x += points[i].x;
            new_centroids[cluster].y += points[i].y;
            counts[cluster]++;
        }
        
        // Check convergence
        bool converged = true;
        for (int j = 0; j < k; j++) {
            if (counts[j] > 0) {
                new_centroids[j].x /= counts[j];
                new_centroids[j].y /= counts[j];
                if (distance(new_centroids[j], centroids[j]) > 1e-5) {
                    converged = false;
                }
            }
            centroids[j] = new_centroids[j];
        }
        
        if (converged) break;
    }
}

int main() {
    const int n = 1000000; // Number of points
    const int k = 10;      // Number of clusters
    const int max_iterations = 100;
    
    // Generate random points
    std::vector<Point> points(n);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dis(0.0f, 1000.0f);
    
    for (int i = 0; i < n; i++) {
        points[i] = {dis(gen), dis(gen)};
    }
    
    // Initialize centroids
    std::vector<Point> centroids(k);
    for (int i = 0; i < k; i++) {
        centroids[i] = points[i * (n / k)];
    }
    
    std::vector<int> assignments;
    
    auto start = std::chrono::high_resolution_clock::now();
    kmeans(points, centroids, assignments, k, max_iterations);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Verify results
    bool correct = true;
    for (int i = 0; i < n; i++) {
        if (assignments[i] < 0 || assignments[i] >= k) {
            correct = false;
            break;
        }
    }
    
    std::cout << "Sequential K-Means Clustering\n";
    std::cout << "Number of points: " << n << "\n";
    std::cout << "Number of clusters: " << k << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result verification: " << (correct ? "PASSED" : "FAILED") << std::endl;
    
    return 0;
} 
//compile with:
// g++ -o kmeans kmeans.cpp -std=c++11
// run with:
// ./kmeans