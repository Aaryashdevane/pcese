#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <openacc.h>

typedef struct {
    float x, y;
} Point;

float distance(Point a, Point b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

void kmeans(Point* points, Point* centroids, int* assignments,
           int n, int k, int max_iterations) {
    #pragma acc data copyin(points[0:n], centroids[0:k]) copyout(assignments[0:n])
    {
        for (int iter = 0; iter < max_iterations; iter++) {
            // Assignment step
            #pragma acc parallel loop
            for (int i = 0; i < n; i++) {
                float min_dist = INFINITY;
                int best_cluster = 0;
                
                #pragma acc loop reduction(min:min_dist)
                for (int j = 0; j < k; j++) {
                    float dist = distance(points[i], centroids[j]);
                    if (dist < min_dist) {
                        min_dist = dist;
                        best_cluster = j;
                    }
                }
                assignments[i] = best_cluster;
            }
            
            // Update step
            Point* new_centroids = (Point*)calloc(k, sizeof(Point));
            int* counts = (int*)calloc(k, sizeof(int));
            
            #pragma acc data copyin(assignments[0:n]) copyout(new_centroids[0:k], counts[0:k])
            {
                #pragma acc parallel loop
                for (int i = 0; i < n; i++) {
                    int cluster = assignments[i];
                    #pragma acc atomic
                    new_centroids[cluster].x += points[i].x;
                    #pragma acc atomic
                    new_centroids[cluster].y += points[i].y;
                    #pragma acc atomic
                    counts[cluster]++;
                }
            }
            
            // Check convergence
            int converged = 1;
            #pragma acc parallel loop reduction(&&:converged)
            for (int j = 0; j < k; j++) {
                if (counts[j] > 0) {
                    Point new_centroid = {
                        new_centroids[j].x / counts[j],
                        new_centroids[j].y / counts[j]
                    };
                    if (distance(new_centroid, centroids[j]) > 1e-5) {
                        converged = 0;
                    }
                    centroids[j] = new_centroid;
                }
            }
            
            free(new_centroids);
            free(counts);
            
            if (converged) break;
        }
    }
}

int main() {
    const int n = 1000000;
    const int k = 10;
    const int max_iterations = 100;
    
    // Allocate memory
    Point* points = (Point*)malloc(n * sizeof(Point));
    Point* centroids = (Point*)malloc(k * sizeof(Point));
    int* assignments = (int*)malloc(n * sizeof(int));
    
    // Initialize points and centroids
    for (int i = 0; i < n; i++) {
        points[i].x = (float)(rand() % 1000);
        points[i].y = (float)(rand() % 1000);
    }
    for (int i = 0; i < k; i++) {
        centroids[i] = points[i * (n / k)];
    }
    
    // Run K-means
    kmeans(points, centroids, assignments, n, k, max_iterations);
    
    // Verify results
    int correct = 1;
    for (int i = 0; i < n; i++) {
        if (assignments[i] < 0 || assignments[i] >= k) {
            correct = 0;
            break;
        }
    }
    
    printf("OpenACC K-Means Clustering\n");
    printf("Number of points: %d\n", n);
    printf("Number of clusters: %d\n", k);
    printf("Result verification: %s\n", correct ? "PASSED" : "FAILED");
    
    // Free memory
    free(points);
    free(centroids);
    free(assignments);
    
    return 0;
} 
// Compile with:
// gcc -fopenacc -o kmeans kmeans.c -lm
// Run with:
// ./kmeans
// Note: Ensure you have OpenACC enabled in your compiler and the necessary libraries installed.