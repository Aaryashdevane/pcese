#include <stdio.h>
#include <stdlib.h>
#include <openacc.h>

void bfs_openacc(int* edges, int* edge_offsets, int* distances, int n, int start) {
    int* visited = (int*)malloc(n * sizeof(int));
    int changed = 1;
    
    #pragma acc enter data copyin(edges[0:edge_offsets[n]], edge_offsets[0:n+1]) \
                          create(distances[0:n], visited[0:n])
    
    // Initialize arrays
    #pragma acc parallel loop
    for (int i = 0; i < n; i++) {
        distances[i] = -1;
        visited[i] = 0;
    }
    
    distances[start] = 0;
    visited[start] = 1;
    
    while (changed) {
        changed = 0;
        
        #pragma acc parallel loop reduction(max:changed)
        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                int current_dist = distances[i];
                int start_idx = edge_offsets[i];
                int end_idx = edge_offsets[i + 1];
                
                for (int j = start_idx; j < end_idx; j++) {
                    int neighbor = edges[j];
                    if (!visited[neighbor]) {
                        distances[neighbor] = current_dist + 1;
                        visited[neighbor] = 1;
                        changed = 1;
                    }
                }
            }
        }
    }
    
    #pragma acc exit data copyout(distances[0:n]) delete(edges[0:edge_offsets[n]], \
                                                       edge_offsets[0:n+1], visited[0:n])
    free(visited);
}

int main() {
    // Example graph (CSR format)
    int n = 8;  // Number of nodes
    int edges[] = {1, 2, 0, 3, 4, 0, 5, 6, 1, 7, 1, 7, 2, 7, 2, 7, 3, 4, 5, 6};
    int edge_offsets[] = {0, 2, 5, 8, 10, 12, 14, 16, 20};
    int* distances = (int*)malloc(n * sizeof(int));
    int start_node = 0;
    
    double start_time = omp_get_wtime();
    bfs_openacc(edges, edge_offsets, distances, n, start_node);
    double end_time = omp_get_wtime();
    
    printf("BFS Results (starting from node %d):\n", start_node);
    for (int i = 0; i < n; i++) {
        printf("Distance to node %d: %d\n", i, distances[i]);
    }
    
    printf("\nTime taken: %f seconds\n", end_time - start_time);
    
    free(distances);
    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   gcc -fopenacc -O3 bfs.c -o bfs_openacc

2. Run:
   ./bfs_openacc

Note:
- Make sure you have GCC with OpenACC support installed
- The code requires an OpenACC-capable GPU
- You might need to set the ACC_DEVICE_TYPE environment variable:
  export ACC_DEVICE_TYPE=nvidia  # For NVIDIA GPUs
  export ACC_DEVICE_TYPE=host    # For CPU execution
- For optimal performance, ensure your GPU has enough memory to handle the graph size
*/ 