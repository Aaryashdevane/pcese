#include <iostream>
#include <vector>
#include <queue>
#include <chrono>

void bfs(const std::vector<std::vector<int>>& graph, int start, std::vector<int>& distances) {
    int n = graph.size();
    std::vector<bool> visited(n, false);
    std::queue<int> q;
    
    distances[start] = 0;
    visited[start] = true;
    q.push(start);
    
    while (!q.empty()) {
        int current = q.front();
        q.pop();
        
        for (int neighbor : graph[current]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                distances[neighbor] = distances[current] + 1;
                q.push(neighbor);
            }
        }
    }
}

int main() {
    // Example graph (adjacency list)
    std::vector<std::vector<int>> graph = {
        {1, 2},     // Node 0
        {0, 3, 4},  // Node 1
        {0, 5, 6},  // Node 2
        {1, 7},     // Node 3
        {1, 7},     // Node 4
        {2, 7},     // Node 5
        {2, 7},     // Node 6
        {3, 4, 5, 6} // Node 7
    };
    
    int n = graph.size();
    std::vector<int> distances(n, -1);
    int start_node = 0;
    
    auto start = std::chrono::high_resolution_clock::now();
    bfs(graph, start_node, distances);
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> elapsed = end - start;
    
    std::cout << "BFS Results (starting from node " << start_node << "):\n";
    for (int i = 0; i < n; i++) {
        std::cout << "Distance to node " << i << ": " << distances[i] << "\n";
    }
    
    std::cout << "\nTime taken: " << elapsed.count() << " seconds\n";
    
    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   g++ -std=c++11 -O3 bfs.cpp -o bfs

2. Run:
   ./bfs

Note: Make sure you have g++ installed and have appropriate permissions to execute the compiled binary.
*/ 