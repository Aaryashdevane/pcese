#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <openacc.h>

double monte_carlo_pi(int num_samples) {
    int inside_circle = 0;
    
    #pragma acc parallel loop reduction(+:inside_circle)
    for (int i = 0; i < num_samples; i++) {
        double x = (double)rand() / RAND_MAX * 2.0 - 1.0;
        double y = (double)rand() / RAND_MAX * 2.0 - 1.0;
        
        if (x * x + y * y <= 1.0) {
            inside_circle++;
        }
    }
    
    return 4.0 * inside_circle / num_samples;
}

int main() {
    const int num_samples = 100000000;
    
    // Initialize random seed
    srand(time(NULL));
    
    double start_time = omp_get_wtime();
    double pi = monte_carlo_pi(num_samples);
    double end_time = omp_get_wtime();
    
    printf("OpenACC Monte Carlo PI Calculation\n");
    printf("Number of samples: %d\n", num_samples);
    printf("Estimated PI: %.15f\n", pi);
    printf("Error: %.15f\n", fabs(pi - 3.14159265358979323846));
    printf("Time taken: %.3f seconds\n", end_time - start_time);
    
    return 0;
} 

// Compile with:
// gcc -fopenacc -o monte_carlo_pi monte_carlo_pi.c -lm
// Run with:
// ./monte_carlo_pi
// Note: Ensure you have OpenACC enabled in your compiler and the necessary libraries installed.