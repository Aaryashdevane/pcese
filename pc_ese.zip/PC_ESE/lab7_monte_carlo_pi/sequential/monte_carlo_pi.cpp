#include <iostream>
#include <random>
#include <chrono>

double monte_carlo_pi(int num_samples) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<double> dis(-1.0, 1.0);
    
    int inside_circle = 0;
    
    for (int i = 0; i < num_samples; i++) {
        double x = dis(gen);
        double y = dis(gen);
        
        if (x * x + y * y <= 1.0) {
            inside_circle++;
        }
    }
    
    return 4.0 * inside_circle / num_samples;
}

int main() {
    const int num_samples = 100000000;
    
    auto start = std::chrono::high_resolution_clock::now();
    double pi = monte_carlo_pi(num_samples);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    std::cout << "Sequential Monte Carlo PI Calculation\n";
    std::cout << "Number of samples: " << num_samples << "\n";
    std::cout << "Estimated PI: " << pi << "\n";
    std::cout << "Error: " << std::abs(pi - 3.14159265358979323846) << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    return 0;
} 

// Compile with:
// g++ -o monte_carlo_pi monte_carlo_pi.cpp -std=c++11
// Run with:
// ./monte_carlo_pi
// Note: Ensure you have a C++11 compatible compiler and the necessary libraries installed.