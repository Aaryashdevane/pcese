#include <CL/sycl.hpp>
#include <iostream>
#include <vector>
#include <chrono>

namespace sycl = cl::sycl;

void vector_add(const std::vector<float>& a, const std::vector<float>& b, std::vector<float>& c) {
    // Create a SYCL queue
    sycl::queue q(sycl::default_selector{});
    
    // Create buffers
    sycl::buffer<float, 1> a_buf(a.data(), sycl::range<1>(a.size()));
    sycl::buffer<float, 1> b_buf(b.data(), sycl::range<1>(b.size()));
    sycl::buffer<float, 1> c_buf(c.data(), sycl::range<1>(c.size()));
    
    // Submit work to queue
    q.submit([&](sycl::handler& h) {
        // Create accessors
        auto a_acc = a_buf.get_access<sycl::access::mode::read>(h);
        auto b_acc = b_buf.get_access<sycl::access::mode::read>(h);
        auto c_acc = c_buf.get_access<sycl::access::mode::write>(h);
        
        // Define kernel
        h.parallel_for(sycl::range<1>(a.size()), [=](sycl::id<1> i) {
            c_acc[i] = a_acc[i] + b_acc[i];
        });
    });
    
    // Wait for completion
    q.wait();
}

int main() {
    const size_t N = 100000000;
    std::vector<float> a(N, 1.0f);
    std::vector<float> b(N, 2.0f);
    std::vector<float> c(N, 0.0f);
    
    auto start = std::chrono::high_resolution_clock::now();
    vector_add(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Verify results
    bool correct = true;
    for (size_t i = 0; i < N; i++) {
        if (c[i] != 3.0f) {
            correct = false;
            break;
        }
    }
    
    std::cout << "OneAPI SYCL Vector Addition\n";
    std::cout << "Vector size: " << N << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result correct: " << (correct ? "Yes" : "No") << "\n";
    
    return 0;
} 

// Compile with:
// g++ -o vector_add vector_add.cpp -fsycl -I/path/to/sycl/include -L/path/to/sycl/lib -lsycl
// Run with:
// ./vector_add
// Note: Ensure you have a SYCL-compatible compiler and the necessary libraries installed.