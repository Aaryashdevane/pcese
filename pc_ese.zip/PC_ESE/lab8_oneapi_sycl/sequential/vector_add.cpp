#include <iostream>
#include <vector>
#include <chrono>

void vector_add(const std::vector<float>& a, const std::vector<float>& b, std::vector<float>& c) {
    for (size_t i = 0; i < a.size(); i++) {
        c[i] = a[i] + b[i];
    }
}

int main() {
    const size_t N = 100000000;
    std::vector<float> a(N, 1.0f);
    std::vector<float> b(N, 2.0f);
    std::vector<float> c(N, 0.0f);
    
    auto start = std::chrono::high_resolution_clock::now();
    vector_add(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Verify results
    bool correct = true;
    for (size_t i = 0; i < N; i++) {
        if (c[i] != 3.0f) {
            correct = false;
            break;
        }
    }
    
    std::cout << "Sequential Vector Addition\n";
    std::cout << "Vector size: " << N << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result correct: " << (correct ? "Yes" : "No") << "\n";
    
    return 0;
} 
// Compile with:
// g++ -o vector_add vector_add.cpp -std=c++11
// Run with:
// ./vector_add
// Note: Ensure you have a C++11 compatible compiler and the necessary libraries installed.
// This code performs vector addition of two large vectors and measures the time taken to complete the operation.
