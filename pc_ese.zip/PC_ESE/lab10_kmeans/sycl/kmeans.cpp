#include <CL/sycl.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include <chrono>

namespace sycl = cl::sycl;

struct Point {
    float x, y;
};

float distance(const Point& a, const Point& b) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

void kmeans(std::vector<Point>& points, std::vector<Point>& centroids, 
           std::vector<int>& assignments, int k, int max_iterations) {
    int n = points.size();
    
    // Create a SYCL queue
    sycl::queue q(sycl::default_selector{});
    
    // Create buffers
    sycl::buffer<Point, 1> points_buf(points.data(), sycl::range<1>(n));
    sycl::buffer<Point, 1> centroids_buf(centroids.data(), sycl::range<1>(k));
    sycl::buffer<int, 1> assignments_buf(assignments.data(), sycl::range<1>(n));
    
    for (int iter = 0; iter < max_iterations; iter++) {
        // Assignment step
        q.submit([&](sycl::handler& h) {
            auto points_acc = points_buf.get_access<sycl::access::mode::read>(h);
            auto centroids_acc = centroids_buf.get_access<sycl::access::mode::read>(h);
            auto assignments_acc = assignments_buf.get_access<sycl::access::mode::write>(h);
            
            h.parallel_for(sycl::range<1>(n), [=](sycl::id<1> idx) {
                int i = idx[0];
                float min_dist = std::numeric_limits<float>::max();
                int best_cluster = 0;
                
                for (int j = 0; j < k; j++) {
                    float dx = points_acc[i].x - centroids_acc[j].x;
                    float dy = points_acc[i].y - centroids_acc[j].y;
                    float dist = std::sqrt(dx * dx + dy * dy);
                    
                    if (dist < min_dist) {
                        min_dist = dist;
                        best_cluster = j;
                    }
                }
                assignments_acc[i] = best_cluster;
            });
        });
        
        // Update step
        q.submit([&](sycl::handler& h) {
            auto points_acc = points_buf.get_access<sycl::access::mode::read>(h);
            auto assignments_acc = assignments_buf.get_access<sycl::access::mode::read>(h);
            auto centroids_acc = centroids_buf.get_access<sycl::access::mode::read_write>(h);
            
            sycl::accessor<int, 1, sycl::access::mode::read_write, sycl::access::target::local> 
                local_counts(sycl::range<1>(k), h);
            sycl::accessor<Point, 1, sycl::access::mode::read_write, sycl::access::target::local> 
                local_centroids(sycl::range<1>(k), h);
            
            h.parallel_for(sycl::nd_range<1>(sycl::range<1>(n), sycl::range<1>(256)), 
                         [=](sycl::nd_item<1> item) {
                int i = item.get_global_id(0);
                int local_id = item.get_local_id(0);
                
                // Initialize local memory
                if (local_id < k) {
                    local_counts[local_id] = 0;
                    local_centroids[local_id] = {0.0f, 0.0f};
                }
                item.barrier(sycl::access::fence_space::local_space);
                
                // Accumulate in local memory
                if (i < n) {
                    int cluster = assignments_acc[i];
                    sycl::atomic_ref<int, sycl::memory_order::relaxed, 
                                   sycl::memory_scope::work_group> 
                        count_atomic(local_counts[cluster]);
                    count_atomic.fetch_add(1);
                    
                    sycl::atomic_ref<float, sycl::memory_order::relaxed, 
                                   sycl::memory_scope::work_group> 
                        x_atomic(local_centroids[cluster].x);
                    x_atomic.fetch_add(points_acc[i].x);
                    
                    sycl::atomic_ref<float, sycl::memory_order::relaxed, 
                                   sycl::memory_scope::work_group> 
                        y_atomic(local_centroids[cluster].y);
                    y_atomic.fetch_add(points_acc[i].y);
                }
                item.barrier(sycl::access::fence_space::local_space);
                
                // Update global centroids
                if (local_id < k) {
                    if (local_counts[local_id] > 0) {
                        local_centroids[local_id].x /= local_counts[local_id];
                        local_centroids[local_id].y /= local_counts[local_id];
                        
                        float dx = local_centroids[local_id].x - centroids_acc[local_id].x;
                        float dy = local_centroids[local_id].y - centroids_acc[local_id].y;
                        if (std::sqrt(dx * dx + dy * dy) > 0.0001f) {
                            centroids_acc[local_id] = local_centroids[local_id];
                        }
                    }
                }
            });
        });
        
        q.wait();
    }
}

int main() {
    const int N = 1000000;  // Number of points
    const int K = 5;        // Number of clusters
    const int MAX_ITER = 100;
    
    // Initialize random number generator
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dis(-10.0f, 10.0f);
    
    // Generate random points
    std::vector<Point> points(N);
    for (int i = 0; i < N; i++) {
        points[i] = {dis(gen), dis(gen)};
    }
    
    // Initialize centroids
    std::vector<Point> centroids(K);
    for (int i = 0; i < K; i++) {
        centroids[i] = {dis(gen), dis(gen)};
    }
    
    std::vector<int> assignments(N);
    
    auto start = std::chrono::high_resolution_clock::now();
    kmeans(points, centroids, assignments, K, MAX_ITER);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    std::cout << "OneAPI SYCL K-Means Clustering\n";
    std::cout << "Number of points: " << N << "\n";
    std::cout << "Number of clusters: " << K << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    // Print final centroids
    std::cout << "Final centroids:\n";
    for (int i = 0; i < K; i++) {
        std::cout << "Cluster " << i << ": (" << centroids[i].x << ", " << centroids[i].y << ")\n";
    }
    
    return 0;
} 
// Compile with:
// g++ -o kmeans kmeans.cpp -fsycl -std=c++11
// Run with:
// ./kmeans
// Note: Ensure you have OneAPI SYCL installed and the necessary libraries linked.