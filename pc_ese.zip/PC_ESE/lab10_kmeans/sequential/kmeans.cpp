#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include <chrono>

struct Point {
    float x, y;
};

float distance(const Point& a, const Point& b) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

void kmeans(std::vector<Point>& points, std::vector<Point>& centroids, 
           std::vector<int>& assignments, int k, int max_iterations) {
    int n = points.size();
    
    for (int iter = 0; iter < max_iterations; iter++) {
        // Assignment step
        for (int i = 0; i < n; i++) {
            float min_dist = std::numeric_limits<float>::max();
            int best_cluster = 0;
            
            for (int j = 0; j < k; j++) {
                float dist = distance(points[i], centroids[j]);
                if (dist < min_dist) {
                    min_dist = dist;
                    best_cluster = j;
                }
            }
            assignments[i] = best_cluster;
        }
        
        // Update step
        std::vector<int> counts(k, 0);
        std::vector<Point> new_centroids(k, {0.0f, 0.0f});
        
        for (int i = 0; i < n; i++) {
            int cluster = assignments[i];
            new_centroids[cluster].x += points[i].x;
            new_centroids[cluster].y += points[i].y;
            counts[cluster]++;
        }
        
        bool converged = true;
        for (int j = 0; j < k; j++) {
            if (counts[j] > 0) {
                new_centroids[j].x /= counts[j];
                new_centroids[j].y /= counts[j];
                
                if (distance(new_centroids[j], centroids[j]) > 0.0001f) {
                    converged = false;
                }
            }
            centroids[j] = new_centroids[j];
        }
        
        if (converged) break;
    }
}

int main() {
    const int N = 1000000;  // Number of points
    const int K = 5;        // Number of clusters
    const int MAX_ITER = 100;
    
    // Initialize random number generator
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dis(-10.0f, 10.0f);
    
    // Generate random points
    std::vector<Point> points(N);
    for (int i = 0; i < N; i++) {
        points[i] = {dis(gen), dis(gen)};
    }
    
    // Initialize centroids
    std::vector<Point> centroids(K);
    for (int i = 0; i < K; i++) {
        centroids[i] = {dis(gen), dis(gen)};
    }
    
    std::vector<int> assignments(N);
    
    auto start = std::chrono::high_resolution_clock::now();
    kmeans(points, centroids, assignments, K, MAX_ITER);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    std::cout << "Sequential K-Means Clustering\n";
    std::cout << "Number of points: " << N << "\n";
    std::cout << "Number of clusters: " << K << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    // Print final centroids
    std::cout << "Final centroids:\n";
    for (int i = 0; i < K; i++) {
        std::cout << "Cluster " << i << ": (" << centroids[i].x << ", " << centroids[i].y << ")\n";
    }
    
    return 0;
} 
// Compile with:
// g++ -o kmeans kmeans.cpp -std=c++11
// Run with:
// ./kmeans
// Note: Ensure you have a C++11 compatible compiler and the necessary libraries installed.
