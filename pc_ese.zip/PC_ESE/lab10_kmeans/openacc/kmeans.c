#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

#define N 1000  // Number of data points
#define K 5     // Number of clusters
#define MAX_ITER 100

void kmeans(float data[N][2], int labels[N], float centroids[K][2]) {
    int i, j, iter;
    int counts[K];
    float new_centroids[K][2];

    for (iter = 0; iter < MAX_ITER; iter++) {
        // Reset centroids and counts
        #pragma acc parallel loop
        for (i = 0; i < K; i++) {
            new_centroids[i][0] = 0.0f;
            new_centroids[i][1] = 0.0f;
            counts[i] = 0;
        }

        // Assign points to the nearest cluster
        #pragma acc parallel loop
        for (i = 0; i < N; i++) {
            float min_dist = INFINITY;
            int best_cluster = 0;

            for (j = 0; j < K; j++) {
                float dx = data[i][0] - centroids[j][0];
                float dy = data[i][1] - centroids[j][1];
                float dist = dx * dx + dy * dy;

                if (dist < min_dist) {
                    min_dist = dist;
                    best_cluster = j;
                }
            }

            labels[i] = best_cluster;

            #pragma acc atomic
            new_centroids[best_cluster][0] += data[i][0];
            #pragma acc atomic
            new_centroids[best_cluster][1] += data[i][1];
            #pragma acc atomic
            counts[best_cluster]++;
        }

        // Update centroids
        #pragma acc parallel loop
        for (i = 0; i < K; i++) {
            if (counts[i] > 0) {
                centroids[i][0] = new_centroids[i][0] / counts[i];
                centroids[i][1] = new_centroids[i][1] / counts[i];
            }
        }
    }
}

int main() {
    float data[N][2];
    int labels[N];
    float centroids[K][2];

    // Initialize data points and centroids
    for (int i = 0; i < N; i++) {
        data[i][0] = rand() % 100;
        data[i][1] = rand() % 100;
    }

    for (int i = 0; i < K; i++) {
        centroids[i][0] = rand() % 100;
        centroids[i][1] = rand() % 100;
    }

    // Run k-means
    kmeans(data, labels, centroids);

    // Print final centroids
    for (int i = 0; i < K; i++) {
        printf("Centroid %d: (%f, %f)\n", i, centroids[i][0], centroids[i][1]);
    }

    return 0;
}
// Compile with:
// gcc -fopenacc -o kmeans kmeans.c -lm
// Run with:
// ./kmeans
// Note: Ensure you have OpenACC enabled in your compiler and the necessary libraries installed.