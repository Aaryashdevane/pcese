#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

void lup_decomposition(std::vector<std::vector<float>>& A, 
                      std::vector<std::vector<float>>& L,
                      std::vector<std::vector<float>>& U,
                      std::vector<int>& P,
                      int n) {
    // Initialize L as identity matrix and U as A
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            L[i][j] = (i == j) ? 1.0f : 0.0f;
            U[i][j] = A[i][j];
        }
        P[i] = i;
    }

    for (int k = 0; k < n; k++) {
        // Find pivot
        float max_val = 0.0f;
        int max_idx = k;
        for (int i = k; i < n; i++) {
            if (std::abs(U[i][k]) > max_val) {
                max_val = std::abs(U[i][k]);
                max_idx = i;
            }
        }

        // Swap rows
        if (max_idx != k) {
            std::swap(P[k], P[max_idx]);
            std::swap(U[k], U[max_idx]);
            for (int i = 0; i < k; i++) {
                std::swap(L[k][i], L[max_idx][i]);
            }
        }

        // Perform elimination
        for (int i = k + 1; i < n; i++) {
            L[i][k] = U[i][k] / U[k][k];
            for (int j = k; j < n; j++) {
                U[i][j] -= L[i][k] * U[k][j];
            }
        }
    }
}

int main() {
    const int n = 4;
    std::vector<std::vector<float>> A = {
        {2.0f, -1.0f, -2.0f, -4.0f},
        {-4.0f, 6.0f, 3.0f, -11.0f},
        {-4.0f, -2.0f, 8.0f, 4.0f},
        {-8.0f, 1.0f, 11.0f, -4.0f}
    };

    std::vector<std::vector<float>> L(n, std::vector<float>(n));
    std::vector<std::vector<float>> U(n, std::vector<float>(n));
    std::vector<int> P(n);

    lup_decomposition(A, L, U, P, n);

    // Print results
    std::cout << "L matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << L[i][j] << " ";
        }
        std::cout << "\n";
    }

    std::cout << "\nU matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << U[i][j] << " ";
        }
        std::cout << "\n";
    }

    std::cout << "\nP vector:\n";
    for (int i = 0; i < n; i++) {
        std::cout << P[i] << " ";
    }
    std::cout << "\n";

    return 0;
} 

// Compile with:
// g++ -o lup_decomposition lup_decomposition.cpp -std=c++11
// Run with:
// ./lup_decomposition
// Note: Ensure you have a C++11 compatible compiler and the necessary libraries installed.