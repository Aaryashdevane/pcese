#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <openacc.h>

void lup_decomposition(float* A, float* L, float* U, int* P, int n) {
    // Initialize L as identity matrix and U as A
    #pragma acc parallel loop collapse(2) present(A, L, U, P)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            L[i * n + j] = (i == j) ? 1.0f : 0.0f;
            U[i * n + j] = A[i * n + j];
        }
        P[i] = i;
    }

    for (int k = 0; k < n; k++) {
        // Find pivot
        float max_val = 0.0f;
        int max_idx = k;
        
        #pragma acc parallel loop reduction(max:max_val)
        for (int i = k; i < n; i++) {
            float val = fabsf(U[i * n + k]);
            if (val > max_val) {
                max_val = val;
                max_idx = i;
            }
        }

        // Swap rows if necessary
        if (max_idx != k) {
            #pragma acc parallel loop
            for (int j = 0; j < n; j++) {
                float temp = U[k * n + j];
                U[k * n + j] = U[max_idx * n + j];
                U[max_idx * n + j] = temp;
            }

            #pragma acc parallel loop
            for (int j = 0; j < k; j++) {
                float temp = L[k * n + j];
                L[k * n + j] = L[max_idx * n + j];
                L[max_idx * n + j] = temp;
            }

            int temp_p = P[k];
            P[k] = P[max_idx];
            P[max_idx] = temp_p;
        }

        // Perform elimination
        #pragma acc parallel loop collapse(2)
        for (int i = k + 1; i < n; i++) {
            for (int j = k; j < n; j++) {
                if (j == k) {
                    L[i * n + k] = U[i * n + k] / U[k * n + k];
                }
                U[i * n + j] -= L[i * n + k] * U[k * n + j];
            }
        }
    }
}

int main() {
    const int n = 4;
    float A[n * n] = {
        2.0f, -1.0f, -2.0f, -4.0f,
        -4.0f, 6.0f, 3.0f, -11.0f,
        -4.0f, -2.0f, 8.0f, 4.0f,
        -8.0f, 1.0f, 11.0f, -4.0f
    };
    
    float* L = (float*)malloc(n * n * sizeof(float));
    float* U = (float*)malloc(n * n * sizeof(float));
    int* P = (int*)malloc(n * sizeof(int));
    
    // Copy data to device
    #pragma acc enter data copyin(A[0:n*n], L[0:n*n], U[0:n*n], P[0:n])
    
    lup_decomposition(A, L, U, P, n);
    
    // Copy results back to host
    #pragma acc exit data copyout(L[0:n*n], U[0:n*n], P[0:n])
    
    // Print results
    printf("L matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%f ", L[i * n + j]);
        }
        printf("\n");
    }
    
    printf("\nU matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%f ", U[i * n + j]);
        }
        printf("\n");
    }
    
    printf("\nP vector:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", P[i]);
    }
    printf("\n");
    
    free(L);
    free(U);
    free(P);
    
    return 0;
} 
// Compile with:
// gcc -fopenacc -o lup lup.c -lm
// Run with:
// ./lup
// Note: Ensure you have OpenACC enabled in your compiler and the necessary libraries installed.
