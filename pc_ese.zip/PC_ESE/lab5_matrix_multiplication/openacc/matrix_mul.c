#include <stdio.h>
#include <stdlib.h>
#include <openacc.h>

void matrix_multiply(float* A, float* B, float* C, int N) {
    #pragma acc parallel loop collapse(2) copyin(A[0:N*N], B[0:N*N]) copyout(C[0:N*N])
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            float sum = 0.0f;
            #pragma acc loop reduction(+:sum)
            for (int k = 0; k < N; k++) {
                sum += A[i * N + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

int main() {
    const int N = 1024;
    float* A = (float*)malloc(N * N * sizeof(float));
    float* B = (float*)malloc(N * N * sizeof(float));
    float* C = (float*)malloc(N * N * sizeof(float));

    // Initialize matrices
    for (int i = 0; i < N * N; i++) {
        A[i] = 1.0f;
        B[i] = 2.0f;
    }

    // Perform matrix multiplication
    matrix_multiply(A, B, C, N);

    // Verify results
    int correct = 1;
    float expected = 2.0f * N;
    for (int i = 0; i < N * N; i++) {
        if (fabs(C[i] - expected) > 1e-5) {
            correct = 0;
            break;
        }
    }

    printf("OpenACC Matrix Multiplication\n");
    printf("Matrix size: %dx%d\n", N, N);
    printf("Result verification: %s\n", correct ? "PASSED" : "FAILED");

    // Free memory
    free(A);
    free(B);
    free(C);

    return 0;
} 
//compile with:
// gcc -fopenacc -o matrix_mul matrix_mul.c -lm
//run with:
// ./matrix_mul
// Note: Ensure you have OpenACC enabled in your compiler and the necessary libraries installed.