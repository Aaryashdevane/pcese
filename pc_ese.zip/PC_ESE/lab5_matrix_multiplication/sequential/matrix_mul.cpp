#include <iostream>
#include <vector>
#include <chrono>

void matrix_multiply(const std::vector<float>& A, const std::vector<float>& B,
                    std::vector<float>& C, int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            float sum = 0.0f;
            for (int k = 0; k < N; k++) {
                sum += A[i * N + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

int main() {
    const int N = 1024; // Matrix size N x N
    std::vector<float> A(N * N, 1.0f); // Initialize with 1.0
    std::vector<float> B(N * N, 2.0f); // Initialize with 2.0
    std::vector<float> C(N * N, 0.0f); // Result matrix

    auto start = std::chrono::high_resolution_clock::now();
    matrix_multiply(A, B, C, N);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;

    // Verify results (all elements should be 2.0 * N)
    bool correct = true;
    float expected = 2.0f * N;
    for (int i = 0; i < N * N; i++) {
        if (std::abs(C[i] - expected) > 1e-5) {
            correct = false;
            break;
        }
    }

    std::cout << "Sequential Matrix Multiplication\n";
    std::cout << "Matrix size: " << N << "x" << N << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result verification: " << (correct ? "PASSED" : "FAILED") << std::endl;

    return 0;
} 