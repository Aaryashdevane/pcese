#include <iostream>
#include <vector>
#include <chrono>

void matrix_multiply(const std::vector<std::vector<float>>& a,
                    const std::vector<std::vector<float>>& b,
                    std::vector<std::vector<float>>& c) {
    int n = a.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            float sum = 0.0f;
            for (int k = 0; k < n; k++) {
                sum += a[i][k] * b[k][j];
            }
            c[i][j] = sum;
        }
    }
}

int main() {
    const int N = 1024;  // Matrix size
    std::vector<std::vector<float>> a(N, std::vector<float>(N, 1.0f));
    std::vector<std::vector<float>> b(N, std::vector<float>(N, 2.0f));
    std::vector<std::vector<float>> c(N, std::vector<float>(N, 0.0f));
    
    auto start = std::chrono::high_resolution_clock::now();
    matrix_multiply(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Verify results
    bool correct = true;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (c[i][j] != 2.0f * N) {
                correct = false;
                break;
            }
        }
        if (!correct) break;
    }
    
    std::cout << "Sequential Matrix Multiplication\n";
    std::cout << "Matrix size: " << N << "x" << N << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result correct: " << (correct ? "Yes" : "No") << "\n";
    
    return 0;
} 

// Compile with:
// g++ -o matrix_multiply matrix_multiply.cpp -std=c++11
// Run with:
// ./matrix_multiply
// Note: Ensure you have a C++11 compatible compiler and the necessary libraries installed.