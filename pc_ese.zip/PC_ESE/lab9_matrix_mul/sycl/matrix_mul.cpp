#include <CL/sycl.hpp>
#include <iostream>
#include <vector>
#include <chrono>

namespace sycl = cl::sycl;

void matrix_multiply(const std::vector<std::vector<float>>& a,
                    const std::vector<std::vector<float>>& b,
                    std::vector<std::vector<float>>& c) {
    int n = a.size();
    
    // Create a SYCL queue
    sycl::queue q(sycl::default_selector{});
    
    // Create buffers
    sycl::buffer<float, 2> a_buf(a.data()->data(), sycl::range<2>(n, n));
    sycl::buffer<float, 2> b_buf(b.data()->data(), sycl::range<2>(n, n));
    sycl::buffer<float, 2> c_buf(c.data()->data(), sycl::range<2>(n, n));
    
    // Submit work to queue
    q.submit([&](sycl::handler& h) {
        // Create accessors
        auto a_acc = a_buf.get_access<sycl::access::mode::read>(h);
        auto b_acc = b_buf.get_access<sycl::access::mode::read>(h);
        auto c_acc = c_buf.get_access<sycl::access::mode::write>(h);
        
        // Define kernel
        h.parallel_for(sycl::range<2>(n, n), [=](sycl::id<2> idx) {
            int i = idx[0];
            int j = idx[1];
            float sum = 0.0f;
            for (int k = 0; k < n; k++) {
                sum += a_acc[i][k] * b_acc[k][j];
            }
            c_acc[i][j] = sum;
        });
    });
    
    // Wait for completion
    q.wait();
}

int main() {
    const int N = 1024;  // Matrix size
    std::vector<std::vector<float>> a(N, std::vector<float>(N, 1.0f));
    std::vector<std::vector<float>> b(N, std::vector<float>(N, 2.0f));
    std::vector<std::vector<float>> c(N, std::vector<float>(N, 0.0f));
    
    auto start = std::chrono::high_resolution_clock::now();
    matrix_multiply(a, b, c);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    
    // Verify results
    bool correct = true;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (c[i][j] != 2.0f * N) {
                correct = false;
                break;
            }
        }
        if (!correct) break;
    }
    
    std::cout << "OneAPI SYCL Matrix Multiplication\n";
    std::cout << "Matrix size: " << N << "x" << N << "\n";
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    std::cout << "Result correct: " << (correct ? "Yes" : "No") << "\n";
    
    return 0;
} 

// Compile with:
// g++ -o matrix_multiply matrix_multiply.cpp -std=c++11 -lOpenCL
// Run with:
// ./matrix_multiply
// Note: Ensure you have a SYCL-compatible compiler and the necessary libraries installed.