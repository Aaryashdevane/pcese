#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <chrono>

void compute_histogram(const std::vector<unsigned char>& image, std::vector<int>& histogram) {
    std::fill(histogram.begin(), histogram.end(), 0);
    for (unsigned char pixel : image) {
        histogram[pixel]++;
    }
}

void compute_cdf(const std::vector<int>& histogram, std::vector<int>& cdf) {
    cdf[0] = histogram[0];
    for (int i = 1; i < 256; i++) {
        cdf[i] = cdf[i-1] + histogram[i];
    }
}

void equalize_image(const std::vector<unsigned char>& input, std::vector<unsigned char>& output,
                   const std::vector<int>& cdf, int total_pixels) {
    float scale = 255.0f / total_pixels;
    for (size_t i = 0; i < input.size(); i++) {
        output[i] = static_cast<unsigned char>(round(cdf[input[i]] * scale));
    }
}

void histogram_equalization(std::vector<unsigned char>& image, int width, int height) {
    std::vector<int> histogram(256, 0);
    std::vector<int> cdf(256, 0);
    
    // Calculate histogram
    for (int i = 0; i < width * height; i++) {
        histogram[image[i]]++;
    }
    
    // Calculate CDF
    cdf[0] = histogram[0];
    for (int i = 1; i < 256; i++) {
        cdf[i] = cdf[i-1] + histogram[i];
    }
    
    // Normalize CDF
    int cdf_min = *std::min_element(cdf.begin(), cdf.end());
    int total_pixels = width * height;
    
    for (int i = 0; i < width * height; i++) {
        image[i] = static_cast<unsigned char>(255 * (cdf[image[i]] - cdf_min) / (total_pixels - cdf_min));
    }
}

int main() {
    const int width = 1024;
    const int height = 1024;
    std::vector<unsigned char> image(width * height);
    
    // Initialize image with some pattern
    for (int i = 0; i < width * height; i++) {
        image[i] = static_cast<unsigned char>(i % 256);
    }
    
    auto start = std::chrono::high_resolution_clock::now();
    histogram_equalization(image, width, height);
    auto end = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken: " << elapsed.count() << " seconds\n";
    
    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   g++ -std=c++11 -O3 histogram.cpp -o histogram

2. Run:
   ./histogram

Note: Make sure you have g++ installed and have appropriate permissions to execute the compiled binary.
*/ 