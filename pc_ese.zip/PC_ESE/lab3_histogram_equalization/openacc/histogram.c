#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <openacc.h>

void compute_histogram(unsigned char* image, int* histogram, int size) {
    #pragma acc parallel loop copyin(image[0:size]) copyout(histogram[0:256])
    for (int i = 0; i < size; i++) {
        #pragma acc atomic
        histogram[image[i]]++;
    }
}

void compute_cdf(int* histogram, int* cdf) {
    #pragma acc parallel loop
    for (int i = 0; i < 256; i++) {
        if (i == 0) {
            cdf[i] = histogram[i];
        } else {
            cdf[i] = cdf[i-1] + histogram[i];
        }
    }
}

void equalize_image(unsigned char* input, unsigned char* output, int* cdf, int size, float scale) {
    #pragma acc parallel loop copyin(input[0:size], cdf[0:256]) copyout(output[0:size])
    for (int i = 0; i < size; i++) {
        output[i] = (unsigned char)round(cdf[input[i]] * scale);
    }
}

int main() {
    const int width = 512;
    const int height = 512;
    const int total_pixels = width * height;

    // Allocate memory
    unsigned char* input_image = (unsigned char*)malloc(total_pixels * sizeof(unsigned char));
    unsigned char* output_image = (unsigned char*)malloc(total_pixels * sizeof(unsigned char));
    int* histogram = (int*)calloc(256, sizeof(int));
    int* cdf = (int*)calloc(256, sizeof(int));

    // Initialize input image (gradient)
    for (int i = 0; i < total_pixels; i++) {
        input_image[i] = (unsigned char)(i % 256);
    }

    // Compute histogram
    compute_histogram(input_image, histogram, total_pixels);

    // Compute CDF
    compute_cdf(histogram, cdf);

    // Equalize image
    float scale = 255.0f / total_pixels;
    equalize_image(input_image, output_image, cdf, total_pixels, scale);

    // Verify results
    int correct = 1;
    for (int i = 0; i < total_pixels; i++) {
        if (output_image[i] < 0 || output_image[i] > 255) {
            correct = 0;
            break;
        }
    }

    printf("OpenACC Histogram Equalization\n");
    printf("Result verification: %s\n", correct ? "PASSED" : "FAILED");

    // Free memory
    free(input_image);
    free(output_image);
    free(histogram);
    free(cdf);

    return 0;
}

/*
Compilation and Execution Commands:
1. Compile:
   gcc -fopenacc -O3 histogram.c -o histogram_openacc

2. Run:
   ./histogram_openacc

Note:
- Make sure you have GCC with OpenACC support installed
- The code requires an OpenACC-capable GPU
- You might need to set the ACC_DEVICE_TYPE environment variable:
  export ACC_DEVICE_TYPE=nvidia  # For NVIDIA GPUs
  export ACC_DEVICE_TYPE=host    # For CPU execution
- For optimal performance, ensure your GPU has enough memory to handle the image size
*/ 